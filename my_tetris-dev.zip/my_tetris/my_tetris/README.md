# Welcome to My Tetris

By Dilshod Alimbekov

## Task

What is the problem? And where is the challenge

no difficulties

## Description

I solved the problem very easily, the task was clear to me

## Installation

no need to do any npm just open the index.html file and see

## Usage

It's very easy to use

Play the easy-to-use slot game and win

### The Core Team

<a href="https://github.com/dilshodalimbekov04">MyTetris</a>

<span><i>Made at <a href='https://qwasar.io'>Qwasar FS -- Full Stack Development</a></i></span>
<span><img alt='Qwasar FS -- Full Stack Development's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px'></span>
